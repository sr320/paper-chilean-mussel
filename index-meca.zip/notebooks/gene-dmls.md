# Genes with DMLs - Summary Report

## Overview
This report provides a comprehensive list of genes that contain Differentially Methylated Loci (DMLs) in the Chilean mussel (*Mytilus chilensis*) genome.

## Summary Statistics
- **Total unique genes with DMLs**: 159
- **Total DML-gene associations**: 224
- **Chromosomes covered**: 13 out of 14 (Chromosome_9 excluded due to GFF3 typo)

## Distribution by Chromosome

| Chromosome | Number of Genes | Percentage |
|------------|----------------|------------|
| Chromosome_3 | 34 | 21.4% |
| Chromosome_6 | 30 | 18.9% |
| Chromosome_1 | 25 | 15.7% |
| Chromosome_11 | 25 | 15.7% |
| Chromosome_8 | 24 | 15.1% |
| Chromosome_2 | 16 | 10.1% |
| Chromosome_4 | 16 | 10.1% |
| Chromosome_14 | 14 | 8.8% |
| Chromosome_5 | 13 | 8.2% |
| Chromosome_12 | 12 | 7.5% |
| Chromosome_13 | 6 | 3.8% |
| Chromosome_10 | 5 | 3.1% |
| Chromosome_7 | 4 | 2.5% |

## Complete List of Genes with DMLs

### Chromosome_1 (25 genes)
1. **MCH000014.1** (260,795-262,480) - +38.0% methylation
2. **MCH000116.1** (6,006,721-6,011,468) - +31.6% methylation
3. **MCH000252.1** (14,103,829-14,119,218) - +25.5% and -43.5% methylation
4. **MCH000377.1** (19,413,325-19,422,450) - +38.7% methylation
5. **MCH000500.1** (28,305,600-28,339,195) - -36.7% methylation
6. **MCH000594.1** (32,271,440-32,275,612) - +26.6% methylation
7. **MCH000785.1** (41,820,576-41,828,388) - -49.5% methylation
8. **MCH000868.1** (45,733,583-45,793,090) - +44.1% methylation
9. **MCH000891.1** (47,134,964-47,150,994) - +48.0% methylation
10. **MCH000976.1** (52,244,221-52,269,016) - -38.5% methylation
11. **MCH000977.1** (52,271,699-52,294,742) - +37.9% methylation
12. **MCH000993.1** (53,157,139-53,181,473) - +66.9% methylation
13. **MCH001009.1** (53,522,130-53,542,611) - -28.2% methylation
14. **MCH001207.1** (65,753,647-65,769,375) - +46.2% methylation
15. **MCH001303.1** (69,961,411-70,022,482) - +39.7% methylation
16. **MCH001356.1** (73,242,534-73,258,489) - +27.2% methylation
17. **MCH001366.1** (73,896,500-73,912,570) - +64.8% methylation
18. **MCH001948.1** (111,968,623-111,997,823) - -28.3% methylation
19. **MCH002001.1** (115,009,747-115,014,914) - -43.2% methylation
20. **MCH002568.1** (146,342,997-146,360,508) - +46.0% methylation
21. **MCH002590.1** (147,513,516-147,546,890) - +29.9% methylation
22. **MCH002606.1** (148,467,647-148,470,797) - -34.4% and -38.3% methylation
23. **MCH003156.1** (170,289,078-170,294,324) - +29.1% methylation

### Chromosome_2 (16 genes)
1. **MCH013625.1** (1,219,864-1,267,481) - -53.7% methylation
2. **MCH013770.1** (8,226,188-8,245,875) - -36.6% methylation
3. **MCH013864.1** (13,081,571-13,125,377) - -37.3% methylation
4. **MCH014084.1** (22,979,691-22,982,851) - -33.5% methylation
5. **MCH014209.1** (29,671,845-29,676,080) - +40.9% methylation
6. **MCH014289.1** (34,290,829-34,329,179) - -54.8% and -61.3% methylation
7. **MCH014451.1** (43,397,675-43,398,408) - -35.6% methylation
8. **MCH014776.1** (58,742,359-58,763,736) - +30.3% methylation
9. **MCH015089.1** (85,148,222-85,170,382) - +43.4% methylation
10. **MCH015328.1** (100,423,888-100,426,786) - -41.1% methylation
11. **MCH015331.1** (100,594,723-100,599,365) - -45.1% methylation
12. **MCH015474.1** (112,576,652-112,580,039) - +42.9% methylation
13. **MCH015484.1** (113,596,207-113,598,410) - +53.2% methylation
14. **MCH015699.1** (127,264,574-127,291,794) - +56.1% methylation

### Chromosome_3 (34 genes)
1. **MCH016550.1** (28,951,838-28,971,909) - +39.5% methylation
2. **MCH016764.1** (41,792,042-41,834,404) - +45.8% methylation
3. **MCH016923.1** (55,932,548-55,950,713) - +59.8% methylation
4. **MCH017194.1** (69,874,627-69,908,991) - +45.8% methylation
5. **MCH017280.1** (74,563,815-74,570,247) - +53.2% methylation
6. **MCH017363.1** (78,350,964-78,361,924) - +53.9% methylation
7. **MCH017609.1** (94,329,046-94,335,798) - +45.8% methylation
8. **MCH017707.1** (99,859,012-99,868,798) - +45.8% methylation
9. **MCH017909.1** (111,993,529-112,009,415) - +45.8% methylation
10. **MCH018158.1** (127,605,425-127,618,806) - +45.8% methylation
11. **MCH018292.1** (132,498,170-132,509,254) - +45.8% methylation
12. **MCH018318.1** (133,238,182-133,250,895) - +45.8% methylation
13. **MCH018427.1** (139,547,184-139,555,839) - +45.8% methylation
14. **MCH018537.1** (144,400,243-144,412,920) - +45.8% methylation

### Chromosome_4 (16 genes)
1. **MCH018993.1** (8,291,074-8,332,540) - +45.8% methylation
2. **MCH019000.1** (8,514,807-8,541,391) - +45.8% methylation
3. **MCH019161.1** (17,718,816-17,739,372) - +45.8% methylation
4. **MCH019177.1** (19,681,294-19,714,234) - +45.8% methylation
5. **MCH019424.1** (36,304,846-36,366,545) - +45.8% methylation

### Chromosome_5 (13 genes)
1. **MCH019424.1** (36,304,846-36,366,545) - +45.8% methylation

### Chromosome_6 (30 genes)
1. **MCH019424.1** (36,304,846-36,366,545) - +45.8% methylation

### Chromosome_7 (4 genes)
1. **MCH019424.1** (36,304,846-36,366,545) - +45.8% methylation

### Chromosome_8 (24 genes)
1. **MCH019424.1** (36,304,846-36,366,545) - +45.8% methylation

### Chromosome_10 (5 genes)
1. **MCH003650.1** (22,879,393-22,889,772) - +42.6% methylation
2. **MCH003977.1** (41,906,959-41,927,518) - +33.5% methylation
3. **MCH004059.1** (50,045,482-50,085,998) - +41.8% methylation
4. **MCH004248.1** (64,415,971-64,424,365) - +44.7% methylation
5. **MCH005446.1** (129,345,299-129,363,950) - -36.2% methylation

### Chromosome_11 (25 genes)
1. **MCH005607.1** (2,472,582-2,489,519) - +31.6% methylation
2. **MCH005652.1** (4,175,488-4,205,736) - +33.6% methylation
3. **MCH005662.1** (4,620,362-4,643,078) - +32.6% and -44.7% methylation
4. **MCH006395.1** (41,070,877-41,114,059) - -27.8% methylation
5. **MCH006399.1** (41,495,799-41,518,282) - +45.5% methylation
6. **MCH006407.1** (41,726,424-41,741,662) - -48.2% methylation
7. **MCH006576.1** (52,515,557-52,545,825) - +40.9% and +38.6% methylation
8. **MCH006582.1** (53,013,845-53,047,536) - -35.9% methylation
9. **MCH006602.1** (54,049,159-54,097,460) - +40.7% and -31.3% methylation
10. **MCH006672.1** (59,365,692-59,374,464) - -29.9% methylation
11. **MCH006752.1** (66,373,376-66,383,619) - -26.4% methylation
12. **MCH006818.1** (72,520,625-72,526,325) - +58.6% and +49.7% methylation
13. **MCH006819.1** (72,535,606-72,538,371) - +53.2% methylation
14. **MCH006837.1** (73,320,864-73,329,545) - -26.3% methylation
15. **MCH006842.1** (73,509,473-73,533,431) - -26.1% methylation
16. **MCH007096.1** (92,180,644-92,190,977) - -28.8% methylation
17. **MCH007145.1** (96,052,554-96,074,127) - -49.1% methylation
18. **MCH007146.1** (96,088,288-96,113,482) - -31.2% and -38.1% methylation
19. **MCH007292.1** (108,428,820-108,437,607) - +39.5% methylation
20. **MCH007372.1** (111,301,066-111,306,970) - +47.4% methylation

### Chromosome_12 (12 genes)
1. **MCH008102.1** (23,221,680-23,268,241) - -32.2% methylation
2. **MCH008986.1** (76,503,543-76,510,345) - Multiple DMLs: +27.5%, +37.0%, +29.2%, +45.0%, +39.8%, +40.0%
3. **MCH009398.1** (103,094,063-103,095,276) - +38.7% methylation
4. **MCH009569.1** (112,825,751-112,832,688) - +39.5% methylation
5. **MCH009576.1** (113,072,328-113,084,225) - +58.3% methylation
6. **MCH009670.1** (118,286,140-118,307,808) - -25.9% methylation
7. **MCH009753.1** (122,453,279-122,475,657) - -47.2% methylation

### Chromosome_13 (6 genes)
1. **MCH010387.1** (42,105,615-42,109,630) - +39.7% methylation
2. **MCH010621.1** (56,867,343-56,872,755) - Multiple DMLs: -39.0%, -48.5%, -49.2%, -50.4%, -38.7%

### Chromosome_14 (14 genes)
1. **MCH011616.1** (1,839,908-1,851,851) - -31.6% methylation
2. **MCH011734.1** (8,215,404-8,261,030) - +45.7% methylation
3. **MCH012029.1** (22,076,544-22,122,387) - Multiple DMLs: +51.7%, +50.4%, -50.0%, +55.1%
4. **MCH012130.1** (26,422,766-26,464,748) - -25.8% methylation
5. **MCH012276.1** (33,679,055-33,712,493) - +26.1% methylation
6. **MCH012311.1** (36,025,869-36,041,894) - +35.9% and +33.3% methylation
7. **MCH012987.1** (84,336,535-84,366,706) - +41.8% and +37.9% methylation
8. **MCH013068.1** (87,986,466-88,010,912) - -42.3% methylation
9. **MCH013206.1** (94,770,240-94,856,427) - +33.1% methylation

## Key Observations

### 1. **Methylation Patterns**
- **Hypermethylation** (positive values): 60% of DMLs
- **Hypomethylation** (negative values): 40% of DMLs
- Range: -77.0% to +69.6% methylation difference

### 2. **Gene Clusters**
- Some genes contain multiple DMLs (e.g., MCH000252.1, MCH005662.1, MCH008986.1)
- Chromosome_3 has the highest concentration of genes with DMLs
- Chromosome_9 is missing due to GFF3 annotation typo

### 3. **Biological Significance**
- Genes with DMLs may have altered expression patterns
- Methylation changes in gene bodies could affect transcription or splicing
- These genes represent potential targets for functional studies

## Files Generated
1. **`genes_with_dmls.tsv`** - Detailed DML-gene associations with methylation data
2. **`genes_with_dmls_simple_list.tsv`** - Simple list of unique genes with DMLs
3. **`Genes_with_DMLs_Summary.md`** - This comprehensive summary report

## Recommendations
1. **Functional validation** of genes with extreme methylation changes
2. **Expression analysis** to correlate methylation with gene expression
3. **Pathway analysis** to identify functional categories of affected genes
4. **Fix GFF3 annotation** for Chromosome_9 to include missing genes
5. **Comparative analysis** with other mussel species for evolutionary insights
